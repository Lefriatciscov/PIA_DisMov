package com.example.dispositivosmoviles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dispositivosmoviles.ui.theme.AstartBlue

data class TrackedUnit(
    val id: String,
    val model: String,
    val driver: String,
    val status: String,
    val statusColor: Color
)

val sampleUnits = listOf(
    TrackedUnit("Unidad 07", "Nissan NP300", "Juan Pérez", "En operación", Color(0xFF2E7D32)),
    TrackedUnit("Unidad 12", "Camión 3.5T", "Pedro Gómez", "Tráfico", Color(0xFFEF6C00)),
    TrackedUnit("Unidad 09", "Vehículo de carga", "Luis Hernández", "Parada", Color.Red)
)

@Composable
fun UnitItem(unit: TrackedUnit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color(0xFFF5F5F5), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.LightGray),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = AstartBlue)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("${unit.id} - ${unit.model}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Conductor: ${unit.driver}", fontSize = 12.sp, color = Color.Gray)
        }
        Surface(
            color = unit.statusColor,
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                unit.status,
                color = Color.White,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
}
