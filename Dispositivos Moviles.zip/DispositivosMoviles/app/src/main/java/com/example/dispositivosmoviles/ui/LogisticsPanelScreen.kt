package com.example.dispositivosmoviles.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dispositivosmoviles.R
import com.example.dispositivosmoviles.ui.theme.AstartBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogisticsPanelScreen(onNavigateToMonitoring: () -> Unit, onNavigateToUnits: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.astart_logo),
                            contentDescription = null,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PANEL PRINCIPAL", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profile", modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = { }) {
                        BadgedBox(badge = { Badge { Text("1") } }) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifications", modifier = Modifier.size(32.dp))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { },
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = null) },
                    label = { Text("Nueva Ruta") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { },
                    icon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text("Buscar") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Ajustes") }
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFE0E0E0))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Resumen de la flota", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SummaryItem("Total de unidades", "24", AstartBlue, Modifier.weight(1f))
                            SummaryItem("En operación", "16", Color(0xFF2E7D32), Modifier.weight(1f), Icons.Default.LocalShipping)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SummaryItem("Paradas", "5", Color(0xFFD84315), Modifier.weight(1f), Icons.Default.Warning)
                            SummaryItem("Incidentes", "3", Color.Red, Modifier.weight(1f), Icons.Default.Report)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        // Simulated progress bar
                        Row(modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))) {
                            Box(modifier = Modifier.weight(0.4f).fillMaxHeight().background(AstartBlue))
                            Box(modifier = Modifier.weight(0.3f).fillMaxHeight().background(Color(0xFF2E7D32)))
                            Box(modifier = Modifier.weight(0.2f).fillMaxHeight().background(Color(0xFFEF6C00)))
                            Box(modifier = Modifier.weight(0.1f).fillMaxHeight().background(Color.Red))
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Alertas recientes", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        AlertItem("Unidad 07 (NP300): Desviación detectada", Color(0xFF2E7D32))
                        AlertItem("Unidad 12 (3.5T): Retraso por tráfico", Color(0xFFEF6C00))
                        AlertItem("Unidad 09: Parada prolongada", Color.Red)
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ShortcutItem("MONITOREO", Icons.Default.Map, Modifier.weight(1f), onClick = onNavigateToMonitoring)
                        ShortcutItem("RUTAS", Icons.Default.Route, Modifier.weight(1f))
                        ShortcutItem("UNIDADES", Icons.Default.LocalShipping, Modifier.weight(1f), onClick = onNavigateToUnits)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ShortcutItem("CONDUCTORES", Icons.Default.Person, Modifier.weight(1f))
                        ShortcutItem("NOTIFICACIONES", Icons.Default.Notifications, Modifier.weight(1f))
                        ShortcutItem("REPORTES", Icons.Default.BarChart, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryItem(title: String, value: String, color: Color, modifier: Modifier, icon: ImageVector? = null) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 12.sp, color = Color.Black)
                Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            }
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
fun AlertItem(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, fontSize = 14.sp)
    }
}

@Composable
fun ShortcutItem(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit = {}) {
    Card(
        modifier = modifier.height(100.dp),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = AstartBlue, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LogisticsPanelScreenPreview() {
    LogisticsPanelScreen(onNavigateToMonitoring = {}, onNavigateToUnits = {})
}
