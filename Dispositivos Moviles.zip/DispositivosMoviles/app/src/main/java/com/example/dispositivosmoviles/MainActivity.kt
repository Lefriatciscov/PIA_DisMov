package com.example.dispositivosmoviles

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.dispositivosmoviles.ui.ForgotPasswordScreen
import com.example.dispositivosmoviles.ui.LoginScreen
import com.example.dispositivosmoviles.ui.LogisticsPanelScreen
import com.example.dispositivosmoviles.ui.MonitoringScreen
import com.example.dispositivosmoviles.ui.UnitsTrackingScreen
import com.example.dispositivosmoviles.ui.theme.DispositivosMovilesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DispositivosMovilesTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "login") {
                    composable("login") {
                        LoginScreen(
                            onForgotPassword = {
                                navController.navigate("forgot_password")
                            },
                            onLoginSuccess = {
                                navController.navigate("logistics_panel")
                            }
                        )
                    }
                    composable("forgot_password") {
                        ForgotPasswordScreen(onBackToLogin = {
                            navController.popBackStack()
                        })
                    }
                    composable("logistics_panel") {
                        LogisticsPanelScreen(
                            onNavigateToMonitoring = {
                                navController.navigate("monitoring")
                            },
                            onNavigateToUnits = {
                                navController.navigate("units_tracking")
                            }
                        )
                    }
                    composable("monitoring") {
                        MonitoringScreen(onBack = {
                            navController.popBackStack()
                        })
                    }
                    composable("units_tracking") {
                        UnitsTrackingScreen(onBack = {
                            navController.popBackStack()
                        })
                    }
                }
            }
        }
    }
}
